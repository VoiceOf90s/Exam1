﻿CREATE TABLE [dbo].[Город]
(
	[Id] INT NOT NULL, 
    [Название] NCHAR(10) NOT NULL		
    PRIMARY KEY CLUSTERED ([Id] ASC)
)
